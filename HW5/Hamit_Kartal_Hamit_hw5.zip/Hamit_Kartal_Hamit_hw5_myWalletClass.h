#ifndef _HAMIT_KARTAL_HAMIT_HW5_MYWALLETCLASS_H
#define _HAMIT_KARTAL_HAMIT_HW5_MYWALLETCLASS_H

#include <iostream>
#include <string>
using namespace std;

struct Money
{
	string currency;
	double amount;
};

class Wallet
{
	public:
		Wallet ();								// default constructor
		Wallet (const Wallet&);					// (deep) copy contructor
		~Wallet();								// destructor

		int does_this_money_exist(const Money &) const;			// checks if given Money object exists in *this, regardless the amount of the currency
		int getSize() const;									// returns the size of the wallet object
		Money* getArr() const;									// returns the first currency exists in the wallet
		
		Wallet operator + (const Money &) const;				// creates a new wallet object. if given money exists in *this, then increases 
																// the corresponding currency and returns the new wallet
																// if doesn't exist, then adds the money at the end of the new wallet object 
																// and returns the new wallet

		Wallet operator+(const Wallet &) const;					// creates a new wallet object. for each money that exists in both lhs & rhs wallet,
																// records the money with sum of the both amounts and adds to the new wallet
																// for each money that exists in exactly one wallet, add the money to the new wallet as it is
																// then returns the new wallet object

		const Wallet& operator=(const Wallet&);					// checks if lhs is equal to rhs. if yes, then returns lhs as it is, doesnt operate anything
																// if not, then destructs lhs, and explicitly (deep) copies the rhs and assign the copy to lhs
																// then returns lhs

		Wallet operator-(const Money &) const;					// if wallet object doesn't contain given money, creates a new wallet object that contains exact
																// same currencies with *this and return the new wallet object

																//if wallet object has exactly same amount as given money contains, then creates a new wallet object
																// with size = (this->size - 1). except the corresponding money, deep copies the other monies in *this to
																// the new wallet and returns the new one afterwards

																// if wallet object has more amount than given money object has, then creates a new wallet object
																// with the same size as *this, explicitly deep copies the currencies in *this to the new one
																// then decreases the amount of corresponding money from new wallet, and returns new wallet afterwards

		bool operator==(const Wallet&) const;					// checks if lhs and rhs wallets have same currencies with same amount regardless the orders
		const Wallet& operator+=(const Wallet & rhs);			// adds the currencies in rhs to *this, with the help of .operator+
	private:
		unsigned size;
		Money* money_arr;
};
ostream& operator << (ostream&, const Wallet &);	// prints the content of the given wallet via output stream
bool operator <= (const Money &, const Wallet &);	// checks if given money amount is smaller than or equal to amount in the given wallet
													// returns false if wallet does not contain given money

bool operator >= (const Wallet&, const Money &);	// checks if given money amount is greater than or equal to amount in the given wallet
													// returns false if wallet does not contain given money
#endif