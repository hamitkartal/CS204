#include "Hamit_Kartal_Hamit_hw5_myWalletClass.h"
using namespace std;

ostream& operator << (ostream& os, const Wallet &wallet)
{
	unsigned size = wallet.getSize();
	Money* ptr = wallet.getArr();
	for (unsigned i=0; i < size; i++)
	{
		if (i == size-1)
			os << ptr[i].currency << " " << ptr[i].amount;
		
		else
			os << ptr[i].currency << " " << ptr[i].amount << " - ";
	}
	return os;
}
bool operator<=(const Money & lhs, const Wallet & rhs)
{
	int index = rhs.does_this_money_exist(lhs);
	Money* ptr = rhs.getArr();
	if (index == -1)
		return false;
	return (lhs.amount <= ptr[index].amount);
}
bool operator>=(const Wallet& lhs, const Money & rhs)
{
	int index = lhs.does_this_money_exist(rhs);
	Money* ptr = lhs.getArr();
	if (index == -1)
		return false;
	return (ptr[index].amount >= rhs.amount);
}

Wallet::Wallet()
{
	size = 0;
	money_arr = NULL;
}
Wallet::Wallet(const Wallet & original)
{
	size = original.size;
	money_arr = new Money [size];

	for (unsigned i=0; i < size; i++)
		money_arr[i] = original.money_arr[i];
}
Wallet::~Wallet()
{
	this->size = 0;
	delete [] this->money_arr;
	this->money_arr = NULL;
}

int Wallet::does_this_money_exist(const Money & money) const
{
	for (unsigned i=0; i < this->size; i++)
	{
		if (this->money_arr[i].currency == money.currency)
			return i;
	}
	return -1;
}
int Wallet::getSize() const
{
	return this->size;
}
Money* Wallet::getArr() const
{
	return this->money_arr;
}

Wallet Wallet::operator+(const Money & rhs) const
{
	int index = does_this_money_exist(rhs);
	if (index == -1)
	{
		Wallet copy;
		copy.size = this->size + 1;
		copy.money_arr = new Money [copy.size];
		for (unsigned i=0; i < size; i++)
			copy.money_arr[i] = this->money_arr[i];
		copy.money_arr[copy.size-1].amount = rhs.amount;
		copy.money_arr[copy.size-1].currency = rhs.currency;
		return copy;
	}
	else
	{
		Wallet copy;
		copy.size = this->size;
		copy.money_arr = new Money [this->size];
		for (unsigned i=0; i < size; i++)
			copy.money_arr[i] = this->money_arr[i];
		copy.money_arr[index].amount += rhs.amount;
		return copy;
	}
}
const Wallet& Wallet::operator=(const Wallet& rhs)
{
	if ((this != &rhs))
	{
		if (this->size != 0) {this->~Wallet();}
		int new_size = rhs.size;
		this->size = new_size;
		this->money_arr = new Money [this->size];
		for (unsigned i=0; i < this->size; i++)
			this->money_arr[i] = rhs.money_arr[i];
	}
	return *this;
}
bool Wallet::operator==(const Wallet& rhs) const
{
	if (this->size != rhs.size)
		return false;
	else
	{
		for (unsigned i=0; i < this->size; i++)
		{
			int index = rhs.does_this_money_exist(this->money_arr[i]);
			if (index == -1)
				return false;
			else if (this->money_arr[i].amount != rhs.money_arr[index].amount)
				return false;
		}
		return true;
	}
}
Wallet Wallet::operator+(const Wallet & rhs) const
{
	Wallet copy;
	copy.size = this->size + rhs.size;
	int index;
	for (unsigned i=0; i < this->size; i++)
	{
		index = rhs.does_this_money_exist(this->money_arr[i]);
		if (index != -1)
			copy.size--;
	}
	copy.money_arr = new Money [copy.size];
	
	for (unsigned i=0; i < this->size; i++)
		copy.money_arr[i] = this->money_arr[i];

	int index_of_copy = this->size;

	for (unsigned i=0; i < rhs.size; i++)
	{
		index = copy.does_this_money_exist(rhs.money_arr[i]);
		if (index == -1)
		{
			copy.money_arr[index_of_copy] = rhs.money_arr[i];
			index_of_copy++;
		}
		else
			copy.money_arr[index].amount += rhs.money_arr[i].amount;
	}
	return copy;
}
Wallet Wallet::operator-(const Money & rhs) const
{
	const int index = this->does_this_money_exist(rhs);
	if (index != -1)
	{
		if (this->money_arr[index].amount > rhs.amount)
		{
			Wallet copy (*this);
			copy.money_arr[index].amount -= rhs.amount;
			return copy;
		}

		else if (this->money_arr[index].amount == rhs.amount)
		{
			Wallet copy;
			copy.size = this->size - 1;
			copy.money_arr = new Money [copy.size];
			for (unsigned i=0,j=0; i < this->size; i++,j++)
			{
				if (index != i)
					copy.money_arr[j] = this->money_arr[i];
				else
					j--;
			}
			return copy;
		}

		else
		{
			Wallet copy(*this);
			return copy;
		}
	}
	
	else
	{
		Wallet copy(*this);
		return copy;
	}
}
const Wallet& Wallet::operator+=(const Wallet & rhs)
{
	*this = *this + rhs;
	return *this;
}