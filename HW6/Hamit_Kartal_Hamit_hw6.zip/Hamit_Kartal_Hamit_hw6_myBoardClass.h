#ifndef _HAMIT_KARTAL_HAMIT_HW6_MYBOARDCLASS
#define _HAMIT_KARTAL_HAMIT_HW6_MYBOARDCLASS


template <class itemType>
struct element
{
	itemType value;
	bool closed;
	element() {}
	element(itemType val, bool status)
	{
		value = val;
		closed = status;
	}
};


template <class itemType>
class Board
{
	public:
		Board(int, int);									// parametric constructor
		~Board();											// destructor
		void readBoardFromFile(ifstream&);					// reads board datas from file
		void displayBoard() const;							// displays the board
		void closeCard(int, int);							// closes the card
		int getRow() const;									// returns the row of matrix
		int getColumn() const;								// returns the column of matrix
		element<itemType>** getMatrix() const;				// returns the matrix
	private:
		int row;
		int colm;
		element<itemType> ** board2d;
};
#include "Hamit_Kartal_Hamit_hw6_myBoardClass.cpp"
#endif