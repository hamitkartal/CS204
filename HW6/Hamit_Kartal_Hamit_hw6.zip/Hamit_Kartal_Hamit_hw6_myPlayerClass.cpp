
template <class itemType>
Player<itemType>::Player(Board<itemType> & brd): board(brd)
{
	this->score = 0;
}

template <class itemType>
itemType Player<itemType>::openCard(const int& r, const int&c)
{
	
	element<itemType>** ptr = this->board.getMatrix();
	ptr[r][c].closed = false;
	return ptr[r][c].value;
}


template <class itemType>
bool Player<itemType>::validMove(const int& r, const int&c)
{
	int row = this->board.getRow();
	int colm = this->board.getColumn();
	element<itemType>** ptr = this->board.getMatrix();
	return (r < row && c < colm && ptr[r][c].closed);
}


template <class itemType>
void Player<itemType>::increaseNumberOfSuccess()
{
	this->score++;
}


template <class itemType>
int Player<itemType>::getNumberOfSuccess()
{
	return score;
}
