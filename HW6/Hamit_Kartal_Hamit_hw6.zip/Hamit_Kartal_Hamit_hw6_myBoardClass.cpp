template <class itemType>
Board<itemType>::Board(int r, int c)
{
	this->row = r;
	this->colm = c;

	this->board2d = new element<itemType>* [this->row];
	for (int i=0; i < this->row; i++)
		this->board2d[i] = new element<itemType> [this->colm];
}


template <class itemType>
Board<itemType>::~Board()
{
	for (int i=0; i < this->row; i++)
		delete [] this->board2d[i];
	delete [] this->board2d;
	this->board2d = NULL;
}


template <class itemType>
void Board<itemType>::readBoardFromFile(ifstream& input)
{
	itemType val;
	string line; 
	int r = 0, c = 0;
	while (getline(input, line))
	{
		istringstream stream(line);
		while (stream >> val)
		{
			this->board2d[r][c].value = val;
			this->board2d[r][c].closed = true;
			c++;
		}
		c = 0;
		r++;
	}
}


template <class itemType>
void Board<itemType>::displayBoard() const
{
	for (int i=0; i < this->row; i++)
	{
		for (int j=0; j < this->colm; j++)
		{
			if (this->board2d[i][j].closed)
				cout << "X ";

			else
				cout << this->board2d[i][j].value << " ";
		}
		cout << endl;
	}
}


template <class itemType>
void Board<itemType>::closeCard(int r, int c)
{
	this->board2d[r][c].closed = true;
}


template <class itemType>
int Board<itemType>::getRow() const
{
	return this->row;
}


template <class itemType>
int Board<itemType>::getColumn() const
{
	return this->colm;
}
template <class itemType>
element<itemType>**  Board<itemType>::getMatrix() const
{
	return this->board2d;
}
