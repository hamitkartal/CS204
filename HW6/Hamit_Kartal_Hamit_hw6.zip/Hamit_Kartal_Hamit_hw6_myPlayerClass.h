#ifndef _HAMIT_KARTAL_HAMIT_HW6_MYPLAYERCLASS
#define _HAMIT_KARTAL_HAMIT_HW6_MYPLAYERCLASS


template <class itemType>
class Player
{
	public:
		Player (Board<itemType> &);					// parametric constructor
		itemType openCard(const int&, const int&);	// opens the card at given indexes
		bool validMove(const int&, const int&);		// checks if card at given index is moveable
		void increaseNumberOfSuccess();				// increases the player's score 
		int getNumberOfSuccess();					// retuns the score of player
	private:
		Board<itemType> & board;
		int score;
};
#include "Hamit_Kartal_Hamit_hw6_myPlayerClass.cpp"

#endif