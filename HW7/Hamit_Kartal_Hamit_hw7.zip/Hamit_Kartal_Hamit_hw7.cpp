#include <iostream>
#include <thread>
#include <mutex>
#include <ctime>
#include <chrono>
#include <iomanip>
#include <random>
#include <time.h>
#include "Hamit_Kartal_Hamit_hw7_HW7DynIntQueue.h"
using namespace std;

HW7DynIntQueue firstQueue, secondQueue;
mutex myMutex1, coutMutex, myMutex2;
int numItems, min_waiting_producer, max_waiting_producer;
int min_waiting_filler, max_waiting_filler, min_waiting_packager, max_waiting_packager;
int counter1=0, counter2=0;

int random_range(const int & min, const int & max) 
{
	static mt19937 generator(time(0));
	uniform_int_distribution<int> distribution(min, max);
	return distribution(generator);
}


void producer(int numItems, int min_waiting_producer, int max_waiting_producer)
{
	for(int i = 1; i <= numItems; i++)
	{
		int random = random_range(min_waiting_producer, max_waiting_producer);
		this_thread::sleep_for(chrono::seconds(random));

		myMutex1.lock();
		firstQueue.enqueue(i);
		int size = firstQueue.getCurrentSize();
		myMutex1.unlock();

		coutMutex.lock();
		time_t tt = chrono::system_clock::to_time_t(chrono::system_clock::now()); 
		struct tm *ptm = new struct tm; 
		localtime_s(ptm, &tt); 
		cout << "Producer has enququed a new box "<< i << " to filling queue (filling queue size is " << size << "): " << put_time(ptm,"%X") << endl;
		delete ptm;
		coutMutex.unlock();
		
		
	}
}

void filler (int fillerId, int min_waiting_filler, int max_waiting_filler)
{
	int item;
	while(counter1 < numItems)
	{	
		myMutex1.lock();
		if (!firstQueue.isEmpty()) 
		{
			firstQueue.dequeue(item);
			counter1++;
			int size1 = firstQueue.getCurrentSize();
			myMutex1.unlock();

			coutMutex.lock();
			time_t tt = chrono::system_clock::to_time_t(chrono::system_clock::now()); 
			struct tm *ptm = new struct tm; 
			localtime_s(ptm, &tt); 
			cout << "Filler " << fillerId << " started filling the box " << item << " (filling queue size: is " << size1 << "): " << put_time(ptm,"%X") <<endl;
			coutMutex.unlock();
			
			int random = random_range(min_waiting_filler, max_waiting_filler);
			this_thread::sleep_for(chrono::seconds(random));

			coutMutex.lock();
			tt = chrono::system_clock::to_time_t(chrono::system_clock::now()); 
			localtime_s(ptm, &tt); 
			cout << "Filler " << fillerId << " finished filling the box "<< item << ": " << put_time(ptm,"%X") << endl;
			coutMutex.unlock();

			myMutex2.lock();
			secondQueue.enqueue(item);
			int size2 = secondQueue.getCurrentSize();
			myMutex2.unlock();
			
			coutMutex.lock();
			tt = chrono::system_clock::to_time_t(chrono::system_clock::now()); 
			localtime_s(ptm, &tt); 
			cout << "Filler " << fillerId << " put box " << item << " into packaging queue (packaging queue size is " << size2 << "): " <<  put_time(ptm,"%X") <<endl;
			coutMutex.unlock();
			delete ptm;
			
		}
		else
			myMutex1.unlock();
	}
}

void packager(int packagerId, int min_waiting_packager, int max_waiting_packager)
{
	int item;
	while(counter2 < numItems)
	{	
		myMutex2.lock();
		if (!secondQueue.isEmpty()) 
		{
			secondQueue.dequeue(item);
			counter2++;
			int size = secondQueue.getCurrentSize();
			myMutex2.unlock();

			coutMutex.lock();
			time_t tt = chrono::system_clock::to_time_t(chrono::system_clock::now()); 
			struct tm *ptm = new struct tm; 
			localtime_s(ptm, &tt); 
			cout << "Packager " << packagerId << " started packing the box " << item << " (packaging queue size: is " << size << "): " << put_time(ptm,"%X") <<endl;
			coutMutex.unlock();
			
			int random = random_range(min_waiting_packager, max_waiting_packager);

			this_thread::sleep_for(chrono::seconds(random));

			coutMutex.lock();
			tt = chrono::system_clock::to_time_t(chrono::system_clock::now());
			localtime_s(ptm, &tt); 
			cout << "Packager " << packagerId << " finished packaging the box " << item << ": " << put_time(ptm,"%X") <<endl;
			delete ptm;
			coutMutex.unlock();
		}
		else
		{
			myMutex2.unlock();
		}
	}
}


int main()
{
	
	cout << "Please enter the total number of items: ";
	cin >> numItems;

	cout << "Please enter the min-max waiting time range of producer:\nMin: ";
	cin >> min_waiting_producer;
	cout << "Max: ";
	cin >> max_waiting_producer;

	cout << "Please enter the min-max waiting time range of filler workers:\nMin: ";
	cin >> min_waiting_filler;
	cout << "Max: ";
	cin >> max_waiting_filler;

	cout << "Please enter the min-max waiting time range of packager workers:\nMin: ";
	cin >> min_waiting_packager;
	cout << "Max: ";
	cin >> max_waiting_packager;

	time_t tt = chrono::system_clock::to_time_t(chrono::system_clock::now()); 
	struct tm *ptm = new struct tm; 
	localtime_s(ptm, &tt); 
	cout << "Simulation starts at: " << put_time(ptm,"%X") << endl;


	thread thr0(&producer, numItems, min_waiting_producer, max_waiting_producer);
	thread thr1(&filler, 1, min_waiting_filler, max_waiting_filler);
	thread thr2(&filler, 2, min_waiting_filler, max_waiting_filler);
	thread thr3(&packager, 1, min_waiting_packager, max_waiting_packager);
	thread thr4(&packager, 2, min_waiting_packager, max_waiting_packager);

	thr0.join();
	thr1.join();
	thr2.join();
	thr3.join();
	thr4.join();

	tt = chrono::system_clock::to_time_t(chrono::system_clock::now());
	localtime_s(ptm, &tt);
	cout << "End of the simulation ends: " << put_time(ptm,"%X") << endl;
	return 0;
}